package dev.furyx.client;

import net.minecraft.client.gui.DrawContext;

/**
 * Small bridge used by the HUD callback. Set for the duration of a HUD render.
 */
public final class FuryxHudContext {
    public static DrawContext current;
    private FuryxHudContext() {}
}
