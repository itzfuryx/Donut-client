package dev.furyx.client;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;

public final class FuryxScreen extends Screen {
    public FuryxScreen() {
        super(Text.literal("FURYX CLIENT"));
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        int panelW = 260;
        int panelH = 180;
        int left = (this.width - panelW) / 2;
        int top = (this.height - panelH) / 2;

        context.fill(0, 0, this.width, this.height, 0x88000000);
        context.fill(left, top, left + panelW, top + panelH, 0xF014141C);
        context.fill(left, top, left + panelW, top + 3, 0xFFFF304F);
        context.drawText(this.textRenderer, Text.literal("FURYX CLIENT"), left + 12, top + 12, 0xFFFF405C, false);
        context.drawText(this.textRenderer, Text.literal("BASIC HUD"), left + 12, top + 38, 0xFFFFFFFF, false);
        context.drawText(this.textRenderer, Text.literal("FPS counter: ON"), left + 12, top + 57, 0xFFE5E5E5, false);
        context.drawText(this.textRenderer, Text.literal("CPS counter: ON"), left + 12, top + 74, 0xFFE5E5E5, false);
        context.drawText(this.textRenderer, Text.literal("Keystrokes: next update"), left + 12, top + 91, 0xFFAAAAAA, false);
        context.drawText(this.textRenderer, Text.literal("Open key: RIGHT SHIFT"), left + 12, top + 119, 0xFFFF8092, false);
        context.drawText(this.textRenderer, Text.literal("ESC to close"), left + 12, top + 145, 0xFFAAAAAA, false);
        super.render(context, mouseX, mouseY, delta);
    }

    @Override
    public boolean shouldPause() {
        return false;
    }
}
