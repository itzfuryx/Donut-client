package dev.furyx.client;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

public final class FuryxClient implements ClientModInitializer {
    private static KeyBinding openGuiKey;
    private static boolean guiOpen = false;
    private static long lastLeftClick = 0L;
    private static long lastRightClick = 0L;
    private static int leftCps = 0;
    private static int rightCps = 0;
    private static long cpsWindowStart = System.currentTimeMillis();
    private static int leftClicksInWindow = 0;
    private static int rightClicksInWindow = 0;

    @Override
    public void onInitializeClient() {
        openGuiKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.furyx.open_gui",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_RIGHT_SHIFT,
                KeyBinding.Category.MISC
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (openGuiKey.wasPressed()) {
                if (client.currentScreen instanceof FuryxScreen) {
                    client.setScreen(null);
                    guiOpen = false;
                } else if (client.currentScreen == null) {
                    client.setScreen(new FuryxScreen());
                    guiOpen = true;
                }
            }
            updateCps();
        });

        HudRenderCallback.EVENT.register((drawContext, tickCounter) -> { FuryxHudContext.current = drawContext; renderHud(); FuryxHudContext.current = null; });
    }

    private static void updateCps() {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client == null || client.getWindow() == null) return;
        long now = System.currentTimeMillis();
        if (now - cpsWindowStart >= 1000L) {
            leftCps = leftClicksInWindow;
            rightCps = rightClicksInWindow;
            leftClicksInWindow = 0;
            rightClicksInWindow = 0;
            cpsWindowStart = now;
        }
        if (client.currentScreen == null) {
            if (client.options.attackKey.isPressed()) {
                if (now - lastLeftClick > 80) {
                    leftClicksInWindow++;
                    lastLeftClick = now;
                }
            }
            if (client.options.useKey.isPressed()) {
                if (now - lastRightClick > 80) {
                    rightClicksInWindow++;
                    lastRightClick = now;
                }
            }
        }
    }

    private static void renderHud() {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client == null || client.player == null || client.options.hudHidden) return;
        var context = FuryxHudContext.current;
        if (context == null) return;
        int x = 8;
        int y = 8;
        context.fill(x - 4, y - 4, x + 130, y + 49, 0xB0101018);
        context.fill(x - 4, y - 4, x + 130, y - 6, 0xFFFF304F);
        context.drawText(client.textRenderer, Text.literal("FURYX CLIENT"), x, y, 0xFFFF405C, true);
        context.drawText(client.textRenderer, Text.literal("FPS: " + client.getCurrentFps()), x, y + 13, 0xFFFFFFFF, true);
        context.drawText(client.textRenderer, Text.literal("CPS: " + leftCps + " | " + rightCps), x, y + 26, 0xFFFFFFFF, true);
    }

    public static boolean isGuiOpen() {
        return guiOpen;
    }
}
