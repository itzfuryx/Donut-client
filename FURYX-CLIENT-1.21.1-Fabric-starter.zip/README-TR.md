# FURYX CLIENT — Fabric 1.21.1 başlangıç projesi

**Bu dosya kaynak kod projesidir; hazır kurulabilir JAR değildir.** Henüz derlenip gerçek cihazda test edilmedi.

## Şu anki temel özellikler
- Kırmızı/siyah Click GUI taslağı
- Menü tuşu: **Right Shift**
- FPS sayacı
- Basit sol/sağ CPS sayacı
- Fabric 1.21.1 / Java 21 hedefi

## Önemli not
Bu ilk taslakta Keystrokes paneli ve mod aç/kapat düğmeleri henüz tamamlanmadı. Derlemeden önce kod gözden geçirilmeli; Fabric API sürümüne göre uyarlama gerekebilir. Herkese açık sunucularda haksız avantaj sağlayan özellikler yerine kozmetik ve izin verilen HUD özelliklerine odaklanır.

## Derleme
Bilgisayarda Java 21 ve Gradle kuruluysa proje klasöründe:
```bash
gradle build
```
Başarılı olursa JAR `build/libs/` altında oluşur. JAR'ı Zalith Launcher'da kullandığın **1.21.1 Fabric** profilinin `mods` klasörüne koy. Fabric API modunun da kurulu olması gerekir.

## Android / Redmi
Telefonun kendisinde derlemek daha zahmetlidir; Android'de Java 21 ve Gradle ortamı gerekir. En kolay yöntem projeyi Java 21 kurulu bilgisayarda derleyip JAR'ı telefona aktarmaktır.
